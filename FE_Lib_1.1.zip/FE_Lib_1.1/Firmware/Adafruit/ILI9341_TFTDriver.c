/*******************************************************************************
 * Project     : ...
 * File        : ILI9341_TFTDriver.c
 *
 * Description : This file contains the definition for a basic set of functions
 * 							 for the ILI9341 TFT LCD driver that can be found on many
 * 							 TFT displays from Adafruit.
 *
 * 							 Note: Most of the code comes from the Adafruit C++ library.
 *
 * Created on  : Jan 23, 2019
 * Author      : Frederic.Vachon  
 *
 * (c) Copyright 2019 Future Electronics - Advanced Engineering Group
 *     All rights reserved
 *
 * DISCLAIMER OF WARRANTY
 * All materials, information and services are provided “as-is” and “as-available”
 * for your use. Future Electronics disclaims all warranties of any kind, either
 * express or implied, including but not limited to, the implied warranties of
 * merchantability and fitness for a particular purpose, title, or non-infringement.
 * You acknowledge and agree that the reference designs and other such design
 * materials included herein are provided as an example only and that you will
 * exercise your own independent analysis and judgment in your use of these
 * materials. Future Electronics assumes no liability for your use of these
 * materials for your product designs.
 *
 * INDEMNIFICATION
 * You agree to indemnify, defend and hold Future Electronics and all of its
 * agents, directors, employees, information providers, licensors and licensees,
 * and affiliated companies (collectively, “Indemnified Parties”), harmless from
 * and against any and all liability and costs (including, without limitation,
 * attorneys’ fees and costs), incurred by the Indemnified Parties in connection
 * with any claim arising out of any breach by You of these Terms and Conditions 
 * of Use or any representations or warranties made by You herein. You will
 * cooperate as fully as reasonably required in Future Electronics’ defense of
 * any claim. Future Electronics reserves the right, at its own expense, to
 * assume the exclusive defense and control of any matter otherwise subject to
 * indemnification by You and You shall not in any event settle any matter
 * without the written consent of Future Electronics.
 *
 * LIMITATION OF LIABILITY
 * Under no circumstances shall Future Electronics, nor its agents, directors,
 * employees, information providers, licensors and licensee, and affiliated
 * companies be liable for any damages, including without limitation, direct,
 * indirect, incidental, special, punitive, consequential, or other damages
 * (including without limitation lost profits, lost revenues, or similar economic
 * loss), whether in contract, tort, or otherwise, arising out of the use or
 * inability to use the materials provided as a reference design, even if we
 * are advised of the possibility thereof, nor for any claim by a third party.
 ******************************************************************************/
#include <stdlib.h>
#include <math.h>

#include "Ada28TFT_Touch.h"
#include "ILI9341_TFTDriver.h"
#include "core_gpio.h"
#include "core_spi.h"
#include "core_pwm.h"

// -- Definitions --------------------------------------------------------------

extern gpio_instance_t g_gpio_ADA28;
extern spi_instance_t g_spi_ADA28;
extern pwm_instance_t	g_pwm_ADA28;
extern uint8_t g_TFT_Model;

#ifndef _swap_int16_t
#define _swap_int16_t(a, b) { int16_t t = a; a = b; b = t; }
#endif

// --- Private functions -------------------------------------------------------

void ILI9341_SPI_Write(uint8_t data_bits) {
  SPI_set_slave_select(ADA28_SPI, SPI_SLAVE_0);    // Selects SPI slave 0
  SPI_transfer_frame(ADA28_SPI, data_bits);        // Transfers data to SPI
  SPI_clear_slave_select(ADA28_SPI, SPI_SLAVE_0);  // deselets SPI slave 0
}


void ILI9341_writeCommand(uint8_t data_bits) {
  GPIO_set_output(ADA28_GPIO, ADA28_TFT, ADA28_TFT_CMD);
  ILI9341_SPI_Write(data_bits);
}


void ILI9341_writeData(uint8_t data_bits) {
  GPIO_set_output(ADA28_GPIO, ADA28_TFT, ADA28_TFT_DATA);
  ILI9341_SPI_Write(data_bits);
}


void ILI9341_setAddrWindow(uint16_t x_zero, uint16_t y_zero, uint16_t x_one,
                           uint16_t y_one) {

	ILI9341_writeCommand(ILI9341_CASET);
	ILI9341_writeData(x_zero >> 8);
	ILI9341_writeData(x_zero & 0xFF);
	ILI9341_writeData(x_one >> 8);
	ILI9341_writeData(x_one & 0xFF);

  ILI9341_writeCommand(ILI9341_PASET);
  ILI9341_writeData(y_zero >> 8);
  ILI9341_writeData(y_zero & 0xFF);
  ILI9341_writeData(y_one >> 8);
  ILI9341_writeData(y_one & 0xFF);

  ILI9341_writeCommand(ILI9341_RAMWR);
}




// --- Public Functions --------------------------------------------------------

void ILI9341_Init(uint8_t intensity) {

  ILI9341_writeCommand(0xEF);
  ILI9341_writeData(0x03);
  ILI9341_writeData(0x80);
  ILI9341_writeData(0x02);

  ILI9341_writeCommand(0xCF);
  ILI9341_writeData(0x00);
  ILI9341_writeData(0xC1);
  ILI9341_writeData(0x30);

  ILI9341_writeCommand(0xED);
  ILI9341_writeData(0x64);
  ILI9341_writeData(0x03);
  ILI9341_writeData(0x12);
  ILI9341_writeData(0x81);

  ILI9341_writeCommand(0xE8);
  ILI9341_writeData(0x85);
  ILI9341_writeData(0x00);
  ILI9341_writeData(0x78);

  ILI9341_writeCommand(0xCB);
  ILI9341_writeData(0x39);
  ILI9341_writeData(0x2C);
  ILI9341_writeData(0x00);
  ILI9341_writeData(0x34);
  ILI9341_writeData(0x02);

  ILI9341_writeCommand(0xF7);
  ILI9341_writeData(0x20);

  ILI9341_writeCommand(0xEA);
  ILI9341_writeData(0x00);
  ILI9341_writeData(0x00);

  ILI9341_writeCommand(ILI9341_PWCTR1);   // Power control
  ILI9341_writeData(0x23);                // VRH[5:0]

  ILI9341_writeCommand(ILI9341_PWCTR2);   // Power control
  ILI9341_writeData(0x10);                // SAP[2:0];BT[3:0]

  ILI9341_writeCommand(ILI9341_VMCTR1);   // VCM control
  ILI9341_writeData(0x3e);
  ILI9341_writeData(0x28);

  ILI9341_writeCommand(ILI9341_VMCTR2);   // VCM control2
  ILI9341_writeData(0x86);

  ILI9341_writeCommand(ILI9341_MADCTL);   // Mem Access Ctrl
  ILI9341_writeData(0x48);

  ILI9341_writeCommand(ILI9341_PIXFMT);
  ILI9341_writeData(0x55);

  ILI9341_writeCommand(ILI9341_FRMCTR1);
  ILI9341_writeData(0x00);
  ILI9341_writeData(0x18);

  ILI9341_writeCommand(ILI9341_DFUNCTR);  // Disp Fn Ctrl
  ILI9341_writeData(0x08);
  ILI9341_writeData(0x82);
  ILI9341_writeData(0x27);

  ILI9341_writeCommand(0xF2);             // 3Gamma Function Disable
  ILI9341_writeData(0x00);

  ILI9341_writeCommand(ILI9341_GAMMASET); // Gamma curve sel
  ILI9341_writeData(0x01);

  ILI9341_writeCommand(ILI9341_GMCTRP1);  // Set Gamma
  ILI9341_writeData(0x0F);
  ILI9341_writeData(0x31);
  ILI9341_writeData(0x2B);
  ILI9341_writeData(0x0C);
  ILI9341_writeData(0x0E);
  ILI9341_writeData(0x08);
  ILI9341_writeData(0x4E);
  ILI9341_writeData(0xF1);
  ILI9341_writeData(0x37);
  ILI9341_writeData(0x07);
  ILI9341_writeData(0x10);
  ILI9341_writeData(0x03);
  ILI9341_writeData(0x0E);
  ILI9341_writeData(0x09);
  ILI9341_writeData(0x00);

  ILI9341_writeCommand(ILI9341_GMCTRN1);    // Set Gamma
  ILI9341_writeData(0x00);
  ILI9341_writeData(0x0E);
  ILI9341_writeData(0x14);
  ILI9341_writeData(0x03);
  ILI9341_writeData(0x11);
  ILI9341_writeData(0x07);
  ILI9341_writeData(0x31);
  ILI9341_writeData(0xC1);
  ILI9341_writeData(0x48);
  ILI9341_writeData(0x08);
  ILI9341_writeData(0x0F);
  ILI9341_writeData(0x0C);
  ILI9341_writeData(0x31);
  ILI9341_writeData(0x36);
  ILI9341_writeData(0x0F);

  ILI9341_writeCommand(ILI9341_SLPOUT);
  for(volatile uint16_t x = 0xfff; x > 0; x--) {} // Delay
  ILI9341_writeCommand(ILI9341_DISPON);
  for(volatile uint16_t x = 0xfff; x > 0; x--) {} // Delay

  // Setup backlight intensity
  #if ADA_BACKLITE_CTRL
    if (ADA28_MODEL == ADA28_1947) PWM_enable(ADA28_PWM, PWM_2);
    ILI9341_TFT_backlite(intensity);
  #endif // ADA_BACKLITE_CTRL

}



void ILI9341_TFT_fillrect(int16_t xpt, int16_t ypt, int16_t width,
                          int16_t height, uint16_t colour) {

  if (xpt >= ILI9341_TFT_WIDTH) width = ILI9341_TFT_WIDTH - xpt;
  if (xpt >= ILI9341_TFT_HEIGHT) height = ILI9341_TFT_HEIGHT - ypt;

  ILI9341_setAddrWindow(xpt, ypt, xpt + width - 1, ypt + height - 1);
  int8_t colour_msb = colour >> 8;
  int8_t colour_lsb = colour;

  GPIO_set_output(ADA28_GPIO, ADA28_TFT, ADA28_TFT_DATA); // Data Command Signal

  for(ypt = height; ypt > 0; ypt--) {
    for(xpt = width; xpt > 0; xpt--) {
    	ILI9341_SPI_Write(colour_msb);
    	ILI9341_SPI_Write(colour_lsb);
    }
  }
  GPIO_set_output(ADA28_GPIO, ADA28_CS, ADA28_CS_TFT); // Chip Select Signal
}


void ILI9341_TFT_fillScreen (uint16_t colour) {
	ILI9341_TFT_fillrect(0, 0, ILI9341_TFT_WIDTH, ILI9341_TFT_HEIGHT, colour);
}


void ILI9341_TFT_fastVLine (int16_t pos_x, int16_t pos_y, int16_t height,
                            int16_t colour) {

  if((pos_x >= ILI9341_TFT_WIDTH) || (pos_y >= ILI9341_TFT_HEIGHT)) return;

  if((pos_y + height - 1) >= ILI9341_TFT_HEIGHT)
    height = ILI9341_TFT_HEIGHT - pos_y;

  ILI9341_setAddrWindow(pos_x, pos_y, pos_x, pos_y + height - 1);
  uint8_t colour_msb = colour >> 8;
  uint8_t colour_lsb = colour;

  GPIO_set_output(ADA28_GPIO, ADA28_TFT, ADA28_TFT_DATA); // Data Command Signal

  while(height --) {
  	ILI9341_SPI_Write(colour_msb);
  	ILI9341_SPI_Write(colour_lsb);
  }
}


void ILI9341_TFT_fastHLine (int16_t pos_x, int16_t pos_y, int16_t width,
                            int16_t colour) {

  if((pos_x >= ILI9341_TFT_WIDTH) || (pos_y >= ILI9341_TFT_HEIGHT)) return;

  if((pos_x + width - 1) >= ILI9341_TFT_WIDTH) width = ILI9341_TFT_WIDTH - pos_x;

  ILI9341_setAddrWindow(pos_x, pos_y, pos_x + width - 1, pos_y);
  uint8_t colour_msb = colour >> 8;
  uint8_t colour_lsb = colour;

  GPIO_set_output(ADA28_GPIO, ADA28_TFT, ADA28_TFT_DATA); // Data Command Signal

  while(width --) {
  	ILI9341_SPI_Write(colour_msb);
  	ILI9341_SPI_Write(colour_lsb);
  }
}


void ILI9341_TFT_drawPixel (int16_t xPt, int16_t yPt, uint16_t colour) {

  if ((xPt < 0) || (xPt >= ILI9341_TFT_WIDTH) || (yPt < 0) || (yPt >= ILI9341_TFT_HEIGHT)) return;
  uint8_t colour_msb = 0;
  colour_msb = colour >> 8;
  uint8_t colour_lsb = 0;
  colour_lsb = colour;
  ILI9341_setAddrWindow(xPt, yPt, xPt + 1 , yPt + 1);
  GPIO_set_output(ADA28_GPIO, ADA28_TFT, ADA28_TFT_DATA); // Data Command Signal
  ILI9341_SPI_Write(colour_msb);
  ILI9341_SPI_Write(colour_lsb);
}


void ILI9341_TFT_drawCircle (int16_t x0, int16_t y0, int16_t radius,
                             uint16_t colour) {

  int16_t f = 1 - radius;
  int16_t ddF_x = 1;
  int16_t ddF_y = -2 * radius;
  int16_t x = 0;
  int16_t y = radius;

  ILI9341_TFT_drawPixel(x0, y0 + radius, colour);
  ILI9341_TFT_drawPixel(x0, y0 - radius, colour);
  ILI9341_TFT_drawPixel(x0 + radius, y0, colour);
  ILI9341_TFT_drawPixel(x0 - radius, y0, colour);

  while (x < y) {
    if (f >= 0) {
      y--;
      ddF_y += 2;
      f += ddF_y;
    }
    x++;
    ddF_x += 2;
    f += ddF_x;

    ILI9341_TFT_drawPixel(x0 + x, y0 + y, colour);
    ILI9341_TFT_drawPixel(x0 - x, y0 + y, colour);
    ILI9341_TFT_drawPixel(x0 + x, y0 - y, colour);
    ILI9341_TFT_drawPixel(x0 - x, y0 - y, colour);
    ILI9341_TFT_drawPixel(x0 + y, y0 + x, colour);
    ILI9341_TFT_drawPixel(x0 - y, y0 + x, colour);
    ILI9341_TFT_drawPixel(x0 + y, y0 - x, colour);
    ILI9341_TFT_drawPixel(x0 - y, y0 - x, colour);
  }
}


// Bresenham's algorithm - thx wikpedia
void ILI9341_TFT_drawLine (int16_t x0, int16_t y0, int16_t x1, int16_t y1,
                           uint16_t colour) {

  int16_t steep = abs(y1 - y0) > abs(x1 - x0);
  if (steep) {
    _swap_int16_t(x0, y0);
    _swap_int16_t(x1, y1);
  }

  if (x0 > x1) {
    _swap_int16_t(x0, x1);
    _swap_int16_t(y0, y1);
  }

  int16_t dx, dy;
  dx = x1 - x0;
  dy = abs(y1 - y0);

  int16_t err = dx / 2;
  int16_t ystep;

  if (y0 < y1) {
    ystep = 1;
  } else {
    ystep = -1;
  }

  for (; x0<=x1; x0++) {
    if (steep) {
    	ILI9341_TFT_drawPixel(y0, x0, colour);
    } else {
    	ILI9341_TFT_drawPixel(x0, y0, colour);
    }
    err -= dy;
    if (err < 0) {
      y0 += ystep;
      err += dx;
    }
  }
}


void ILI9341_TFT_backlite(uint8_t intensity){

  uint32_t value = round((ADA28_TFT_BL_CYCLE * intensity) / 100);

  if (ADA28_MODEL == ADA28_1651) PWM_set_duty_cycle(ADA28_PWM, PWM_1, value);
  if (ADA28_MODEL == ADA28_1947) PWM_set_duty_cycle(ADA28_PWM, PWM_2, value);
}








