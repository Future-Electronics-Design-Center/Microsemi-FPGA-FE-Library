/*******************************************************************************
 * Project     : ...
 * File        : Ada28TFT_Touch.h
 *
 * Description : This file contains a definition for a basic TFT touchscreen
 * 							 and support two models from the Adafruit 2.8" TFT touchscreen
 * 							 series: the 1651 Resistive touch and the 1947 Capacitive touch.
 *
 * 							 By setting ADA_BACKLITE_CTRL constant to 1 will activate the
 * 							 capability to set the TFT backlight intensity. Ensure to close
 * 							 the appropriate jumper behind your display.
 *
 * 							 By using the ADA28_SelectTFT function in your main program, the
 * 							 driver will setup itself properly to interact with the detected
 * 							 dislay.
 *
 * Created on  : Jan 23, 2019
 * Author      : Frederic.Vachon  
 *
 * (c) Copyright 2019 Future Electronics - Advanced Engineering Group
 *     All rights reserved
 *
 * DISCLAIMER OF WARRANTY
 * All materials, information and services are provided “as-is” and “as-available”
 * for your use. Future Electronics disclaims all warranties of any kind, either
 * express or implied, including but not limited to, the implied warranties of
 * merchantability and fitness for a particular purpose, title, or non-infringement.
 * You acknowledge and agree that the reference designs and other such design
 * materials included herein are provided as an example only and that you will
 * exercise your own independent analysis and judgment in your use of these
 * materials. Future Electronics assumes no liability for your use of these
 * materials for your product designs.
 *
 * INDEMNIFICATION
 * You agree to indemnify, defend and hold Future Electronics and all of its
 * agents, directors, employees, information providers, licensors and licensees,
 * and affiliated companies (collectively, “Indemnified Parties”), harmless from
 * and against any and all liability and costs (including, without limitation,
 * attorneys’ fees and costs), incurred by the Indemnified Parties in connection
 * with any claim arising out of any breach by You of these Terms and Conditions 
 * of Use or any representations or warranties made by You herein. You will
 * cooperate as fully as reasonably required in Future Electronics’ defense of
 * any claim. Future Electronics reserves the right, at its own expense, to
 * assume the exclusive defense and control of any matter otherwise subject to
 * indemnification by You and You shall not in any event settle any matter
 * without the written consent of Future Electronics.
 *
 * LIMITATION OF LIABILITY
 * Under no circumstances shall Future Electronics, nor its agents, directors,
 * employees, information providers, licensors and licensee, and affiliated
 * companies be liable for any damages, including without limitation, direct,
 * indirect, incidental, special, punitive, consequential, or other damages
 * (including without limitation lost profits, lost revenues, or similar economic
 * loss), whether in contract, tort, or otherwise, arising out of the use or
 * inability to use the materials provided as a reference design, even if we
 * are advised of the possibility thereof, nor for any claim by a third party.
 ******************************************************************************/

#ifndef Ada28TFT_Touch_H_
#define Ada28TFT_Touch_H_

#include "cpu_types.h"

#ifndef NULL
#define NULL  (void*) 0
#endif

// -- Model ------------------------------------------------------------------
#define ADA28_MODEL           g_TFT_Model
#define ADA28_1651            0         // 2.8 TFT Resistive Touch
#define ADA28_1947            1         // 2.8 TFT Capacitive Touch

#define ADA_BACKLITE_CTRL			1         // Backlight intensity controlled by
																				// PWM

// -- Definitions ------------------------------------------------------------
#define ADA28_GPIO          	&g_gpio_ADA28
#define ADA28_SPI           	&g_spi_ADA28
#define ADA28_I2C           	&g_i2c_ADA28
#define ADA28_PWM							&g_pwm_ADA28

#define ADA28_GPIO_ADDR 			0x00000000UL
#define ADA28_SPI_ADDR 				0x00000100UL
#define ADA28_I2C_ADDR 				0x00000200UL
#define ADA28_PWM_ADDR 				0x00000300UL
#define ADA28_I2C_DUMMY_ADDR 	0x10UL

#define ADA28_RSTn 		    		GPIO_0		// Reset
#define ADA28_RSTn_ON	  			0
#define ADA28_RSTn_OFF				1

#define ADA28_TFT							GPIO_1		// Data/Command Select
#define ADA28_TFT_CMD					0
#define ADA28_TFT_DATA				1

#define ADA28_CS   		 				GPIO_2		// Chip Select
#define ADA28_CS_TS	  				0
#define ADA28_CS_TFT					1

#define ADA28_TFT_BL_CYCLE		1000			// Backlight PWM period

typedef struct TS_Point {
  uint8_t id;   // Point ID, 4 bits
  uint16_t x;   // X coordinate, 12 bits
  uint16_t y;   // Y coordinate, 12 bits
  uint8_t w;    // Weight, 8 bits
  uint8_t area; // Area, 4 bits
} TS_Point;


// --- Public Functions --------------------------------------------------------

/*-------------------------------------------------------------------------*//**
  The ADA28_Init() initialized the different hardware interfaces required by the
  Adafruit TFT touchscreen like SPI, I2C, PWM or GPIO.

  @param interface_addr
    The base address of the interface based on the FPGA memory map. This value
    is usually a 32 bits HEX value (ie 0x6000 2000) with the 12 bits LSB 
    being reserved for the interface.

  @return
    none.

  */
void ADA28_Init(addr_t interface_addr);

/*-------------------------------------------------------------------------*//**
  The ADA28_SelectTFT() function sets the API and returns the id of the
  detected Adafruit TFT screen.

  @param
		none.

  @return
		Return 0 if no display is detected. 1 for 1651 and 2 for the 1947.

  */
uint8_t ADA28_SelectTFT();

/*-------------------------------------------------------------------------*//**
  The ADA28_Config() function configures the different ICs based on the
  detected display model.

  @param intensity
		Value for backlight intensity (0-100)

  @return
		none.

  */
void ADA28_Config(uint8_t intensity);

/*-------------------------------------------------------------------------*//**
  The ADA28_Reset() resets all functions of the display.

  @param
		none.

  @return
		none.

  */
void ADA28_Reset();

/*-------------------------------------------------------------------------*//**
  The ADA28_TFT_fillrect() draws a filled rectangle.

  @param xpt
    X-axis coordinate of the lower-left corner (pixel unit)

  @param ypt
    Y-axis coordinate of the lower-left corner (pixel unit)

  @param width
    Width (X-axis) of the rectangle (pixel unit)

  @param height
    Height (Y-axis) of the rectangle (pixel unit)

  @param colour
    Filling colour of the rectangle

  @return
    none.

  */
void ADA28_TFT_fillrect(int16_t xpt, int16_t ypt, int16_t width,
                        int16_t height, uint16_t colour);

/*-------------------------------------------------------------------------*//**
  The ADA28_TFT_fillScreen() paints the screen with the required colour.

  @param colour
    Filling colour of the rectangle

  @return
    none.

  */
void ADA28_TFT_fillScreen(uint16_t colour);

/*-------------------------------------------------------------------------*//**
  The ADA28_TFT_fastVLine() draws a vertical line of the required colour.

  @param pos_x
    X-axis coordinate of the lower end of the line (pixel unit)

  @param pos_y
    Y-axis coordinate of the lower end of the line (pixel unit)

  @param height
    Height (Y-axis) of the line (pixel unit)

  @param colour
    Colour of the line

  @return
    none.

  */
void ADA28_TFT_fastVLine(int16_t pos_x, int16_t pos_y, int16_t height,
                         int16_t colour);

/*-------------------------------------------------------------------------*//**
  The ADA28_TFT_fastHLine() draws an horizontal line of the required colour.

  @param pos_x
    X-axis coordinate of the left end of the line (pixel unit)

  @param pos_y
    Y-axis coordinate of the left end of the line (pixel unit)

  @param height
    Width (X-axis) of the line (pixel unit)

  @param colour
    Colour of the line

  @return
    none.

  */
void ADA28_TFT_fastHLine(int16_t pos_x, int16_t pos_y, int16_t width,
                         int16_t colour);

/*-------------------------------------------------------------------------*//**
  The ADA28_TFT_drawPixel() draws a pixel of the required colour.

  @param xPt
    X-axis coordinate of the pixel (pixel unit)

  @param yPt
    Y-axis coordinate of the pixel (pixel unit)

  @param colour
    Colour of the pixel

  @return
    none.

  */
void ADA28_TFT_drawPixel(int16_t xPt, int16_t yPt, uint16_t colour);

/*-------------------------------------------------------------------------*//**
  The ADA28_TFT_drawCircle() draws a circle of the required colour.

  @param x0
    X-axis coordinate of the center of the circle (pixel unit)

  @param y0
    Y-axis coordinate of the center of the circle (pixel unit)

  @param radius
    Radius (pixel unit)

  @param colour
    Colour of the circle

  @return
    none.

  */
void ADA28_TFT_drawCircle(int16_t x0, int16_t y0, int16_t radius,
                          uint16_t color);

/*-------------------------------------------------------------------------*//**
  The ADA28_TFT_drawLine() draws a line of the required colour.

  @param x0
    X-axis coordinate of one end of the line (pixel unit)

  @param y0
    Y-axis coordinate of one end of the line (pixel unit)

  @param x1
    X-axis coordinate of the other end of the line (pixel unit)

  @param y1
    Y-axis coordinate of the other end of the line (pixel unit)

  @param colour
    Colour of the line

  @return
    none.

  */
void ADA28_TFT_drawLine(int16_t x0, int16_t y0, int16_t x1, int16_t y1,
                        uint16_t color);

/*-------------------------------------------------------------------------*//**
  The ADA28_TFT_SetBacklight() is used to set the PWM associated with the TFT
  backlight to the required duty cycle to provide an intensity from 0 to 100%.

  @param intensity
    Value for backlight intensity (0-100)

  @return
    none.

  */
void ADA28_TFT_SetBacklight(uint8_t intensity);

/*-------------------------------------------------------------------------*//**
  The ADA28_TS_ResetIRQ() clears all flags of the Interrupt Status register.

  This function must be used when a 1651 display is used.

  @param
		none.

  @return
    none.

  */
void ADA28_TS_ResetIRQ();

/*-------------------------------------------------------------------------*//**
  The ADA28_TS_I2CIRQ() is used to drive the CoreI2C interrupt service routine
  on the host. It will runs the I2C state machine to ensure proper communication
  between the host and the FT6206.

  This function must be used when a 1947 display is used.

  @param
		none.

  @return
    none.

  */
void ADA28_TS_I2CIRQ();

/*-------------------------------------------------------------------------*//**
  The ADA28_TS_Touched() returns information about the screen being touched.
  The return value can be different from one display to another.

  @param
		none.

  @return
    1651: TSC Status (0: no touch, 1: touched)
    1947: Number of touches detected, can be 0, 1 or 2

  */
uint8_t ADA28_TS_Touched();

/*-------------------------------------------------------------------------*//**
  The ADA28_TS_GetPoint() reads the content of the touch data registers and
  packs it into the TS_Point data structure.

  @param *point
		Pointer to a TS_Point structure.

  @return
    none.

  */
void ADA28_TS_GetPoint(TS_Point *point);


#endif /* Ada28TFT_Touch_H_ */
