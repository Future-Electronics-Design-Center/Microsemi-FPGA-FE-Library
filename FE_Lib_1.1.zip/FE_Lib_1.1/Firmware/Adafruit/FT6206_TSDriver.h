/*******************************************************************************
 * Project     : ...
 * File        : FT6206_TSDriver.h
 *
 * Description : This file contains low level driver for the FT6206 Capacitive
 *               touch screen controller that can be found on the 1947 display
 *               from Adafruit. It uses an I2C interface to communicate with its
 *               host.
 *
 * Created on  : Jan 23, 2019
 * Author      : Frederic.Vachon  
 *
 * (c) Copyright 2019 Future Electronics - Advanced Engineering Group
 *     All rights reserved
 *
 * DISCLAIMER OF WARRANTY
 * All materials, information and services are provided “as-is” and “as-available”
 * for your use. Future Electronics disclaims all warranties of any kind, either
 * express or implied, including but not limited to, the implied warranties of
 * merchantability and fitness for a particular purpose, title, or non-infringement.
 * You acknowledge and agree that the reference designs and other such design
 * materials included herein are provided as an example only and that you will
 * exercise your own independent analysis and judgment in your use of these
 * materials. Future Electronics assumes no liability for your use of these
 * materials for your product designs.
 *
 * INDEMNIFICATION
 * You agree to indemnify, defend and hold Future Electronics and all of its
 * agents, directors, employees, information providers, licensors and licensees,
 * and affiliated companies (collectively, “Indemnified Parties”), harmless from
 * and against any and all liability and costs (including, without limitation,
 * attorneys’ fees and costs), incurred by the Indemnified Parties in connection
 * with any claim arising out of any breach by You of these Terms and Conditions 
 * of Use or any representations or warranties made by You herein. You will
 * cooperate as fully as reasonably required in Future Electronics’ defense of
 * any claim. Future Electronics reserves the right, at its own expense, to
 * assume the exclusive defense and control of any matter otherwise subject to
 * indemnification by You and You shall not in any event settle any matter
 * without the written consent of Future Electronics.
 *
 * LIMITATION OF LIABILITY
 * Under no circumstances shall Future Electronics, nor its agents, directors,
 * employees, information providers, licensors and licensee, and affiliated
 * companies be liable for any damages, including without limitation, direct,
 * indirect, incidental, special, punitive, consequential, or other damages
 * (including without limitation lost profits, lost revenues, or similar economic
 * loss), whether in contract, tort, or otherwise, arising out of the use or
 * inability to use the materials provided as a reference design, even if we
 * are advised of the possibility thereof, nor for any claim by a third party.
 ******************************************************************************/

#ifndef FT6206_TSDriver_H_
#define FT6206_TSDriver_H_

#include "cpu_types.h"

#ifndef NULL
#define NULL  (void*) 0
#endif

// -- Definitions ------------------------------------------------------------

#define FT62XX_ADDR                 0x38

// -- Register ---------------------------------------------------------------

// Device Mode: R/W, 8 bits, default: 0x00
//  bit 7   : Reserved
//  bit 6:4	: Device Mode (000: Working, 100: Factory)
//  bit 3:0 : Reserved
#define FT62XX_DEV_MODE             0x00
#define FT62XX_DEV_MODE_WORKING     0x00
#define FT62XX_DEV_MODE_FACTORY     0x04

// Gesture of a valid touch: R, 8 bits, default: 0x00
//  bit 7:0 :
#define FT62XX_GEST_ID              0x01
#define FT62XX_GEST_ID_NO_GESTURE   0x00
#define FT62XX_GEST_ID_MOVE_UP      0x10
#define FT62XX_GEST_ID_MOVE_RIGHT   0x14
#define FT62XX_GEST_ID_MOVE_DOWN    0x18
#define FT62XX_GEST_ID_MOVE_LEFT    0x1C
#define FT62XX_GEST_ID_ZOOM_IN      0x48
#define FT62XX_GEST_ID_ZOOM_OUT     0x49

// Number of touch points: R, 8 bits, default: 0x00
//  bit 7:4 : Reserved
//  bit 3:0 : Number of touch points (1-2 is valid)
#define FT62XX_TD_STATUS            0x02

// 1st Touch data: R, 8 bits, default: 0xFF
//  bit 7:6	: Event flag
//  bit 3:0 : X value (MSB)
#define FT62XX_P1_XH                0x03
// 	bit 7:0 : X value (LSB)
#define FT62XX_P1_XL                0x04
//  bit 7:4	: ID
//	bit 3:0	: Y value (MSB)
#define FT62XX_P1_YH                0x05
//  bit 7:0 : Y value (LSB)
#define FT62XX_P1_YL                0x06
//  bit 7:0 : Weight
#define FT62XX_P1_WEIGHT            0x07
//  bit 7:4 Touch area
#define FT62XX_P1_MISC              0x08

// 2st Touch data: R, 8 bits, default: 0xFF
//  bit 7:6	: Event flag
//  bit 3:0 : X value (MSB)
#define FT62XX_P2_XH                0x09
// 	bit 7:0 : X value (LSB)
#define FT62XX_P2_XL                0x0A
//  bit 7:4	: ID
//	bit 3:0	: Y value (MSB)
#define FT62XX_P2_YH                0x0B
//  bit 7:0 : Y value (LSB)
#define FT62XX_P2_YL                0x0C
//  bit 7:0 : Weight
#define FT62XX_P2_WEIGHT            0x0D
//  bit 7:4 Touch area
#define FT62XX_P2_MISC              0x0E

// Threshold for touch detection, R/W, 8 bits
#define FT62XX_TH_GROUP             0x80
#define FT62XX_TH_GROUP_DEFAULT     128     // Calibrated for Adafruit 2.8" 
                                            // CTP screen

// Threshold Filter coefficient: R/W, 8 bits
//  bit 7:0	: Value
#define FT62XX_TH_DIFF							0x85

// Controller Mode: R/W, 8 bits, default: 0x01
//  bit 7:0	: Mode (0x00: stay Active, 0x01: Active to Monitor went no touch)
#define FT62XX_CTRL         				0x86

// Period to switch from Active to Monitor: R/W, 8 bits, default: 0x0A
//  bit 7:0	: Value
#define FT62XX_TIMEENTERMONITOR     0x87

// Report rate in Active mode: R/W, 8 bits
#define FT62XX_PERIODACTIVE         0x88

// Report rate in Monitor mode: R/W, 8 bits
#define FT62XX_PERIODMONITOR        0x89

// Chip Identification: R, 8 bits, default: 0x06
//  bit 7:0	: Chip ID
#define FT62XX_CIPHER               0xA3
#define FT62XX_CIPHER_FT6206        0x06
#define FT62XX_CIPHER_FT6236        0x36

// Interrupt Mode, R/W, 8 bits, default: 0x01
//  bit 7:0	: IRQ mode (0x00: Polling, 0x01: Trigger)
#define FT62XX_G_MODE								0xA4
#define FT62XX_G_MODE_POLL					0x00
#define FT62XX_G_MODE_TRIG					0x01

// Power Mode: R/W, 8 bits, default 0x00
//  bit 7:0	: System Power Mode
#define FT62XX_PWR_MODE							0xA5

// Firmware Version: R, 8 bits
//  bit 7:0	: Version
#define FT62XX_FIRMID               0xA6

// Panel ID: R/W, 8 bits, default: 0x11
//  bit 7:0 : Panel ID
#define FT62XX_FOCALTECH_ID         0xA8
#define FT62XX_FOCALTECH_ID_PANEL   0x11

// Operating Mode: R/W, 8 bits, default: 0x01
//  bit 7:0 : Current Operating Mode
#define FT62XX_STATE                0xBC


typedef int bool;
#define true 1
#define false 0




// --- Public Functions --------------------------------------------------------

/*-------------------------------------------------------------------------*//**
  The FT6206_Init() initialized different hardware parameters related to
  the FT6206 Self-Capacitive Touch Panel controller.

  @param
    none.

  @return
    True if a FT6x06 is found, false on any failure.

  */
uint8_t FT6206_Init();

/*-------------------------------------------------------------------------*//**
  The FT6206_ValidateID() reads and validate the touchscreen controller ID
  for compatibility with this driver.

  @param
		none.

  @return
    True if ID valid, false if not.

  */
uint8_t FT6206_ValidateID();

/*-------------------------------------------------------------------------*//**
  The FT6206_ValidateModel() reads and validate the touchscreen controller
  model for compatibility with this driver.

  @param
		none.

  @return
    True if model valid, false if not.

  */
uint8_t FT6206_ValidateModel();

/*-------------------------------------------------------------------------*//**
  The FT6206_IRQ() is used to drive the CoreI2C interrupt service routine on
  the host. It will runs the I2C state machine to ensure proper communication
  between the host and the FT6206.

  @param
		none.

  @return
    none.

  */
void FT6206_IRQ();

/*-------------------------------------------------------------------------*//**
  The FT6206_Touched() returns the number of touches detected.

  @param
		none.

  @return
    Number of touches detected, can be 0, 1 or 2

  */
uint8_t FT6206_Touched();

/*-------------------------------------------------------------------------*//**
  The FT6206_GetPoint() reads the content of the touch data registers and
  packs it into the TS_Point data structure. It extracts the id, x, y, weight
  and area of the touch.

  Note: In its current form, it only extract 1 point even if 2 touches are
  reported.

  @param *point
		Pointer to a TS_Point structure. See Ada28TFT_Touch.h for more details on
		TS_Point.

  @return
    none.

  */
void FT6206_GetPoint(TS_Point *point);


#endif /* FT6206_TSDriver_H_ */
