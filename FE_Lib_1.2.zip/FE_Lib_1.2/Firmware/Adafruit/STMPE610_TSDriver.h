/*******************************************************************************
 * Project     : ...
 * File        : STMPE610_TSDriver.h
 *
 * Description : This file contains low level driver for the STMPE610 Resistive
 *               touch screen controller that can be found on the 1651 display
 *               from Adafruit. It uses a SPI interface to communicate with its
 *               host.
 *
 * Created on  : Jan 22, 2019
 * Author      : Frederic.Vachon  
 *
 * (c) Copyright 2019 Future Electronics - Advanced Engineering Group
 *     All rights reserved
 *
 * DISCLAIMER OF WARRANTY
 * All materials, information and services are provided “as-is” and “as-available”
 * for your use. Future Electronics disclaims all warranties of any kind, either
 * express or implied, including but not limited to, the implied warranties of
 * merchantability and fitness for a particular purpose, title, or non-infringement.
 * You acknowledge and agree that the reference designs and other such design
 * materials included herein are provided as an example only and that you will
 * exercise your own independent analysis and judgment in your use of these
 * materials. Future Electronics assumes no liability for your use of these
 * materials for your product designs.
 *
 * INDEMNIFICATION
 * You agree to indemnify, defend and hold Future Electronics and all of its
 * agents, directors, employees, information providers, licensors and licensees,
 * and affiliated companies (collectively, “Indemnified Parties”), harmless from
 * and against any and all liability and costs (including, without limitation,
 * attorneys’ fees and costs), incurred by the Indemnified Parties in connection
 * with any claim arising out of any breach by You of these Terms and Conditions 
 * of Use or any representations or warranties made by You herein. You will
 * cooperate as fully as reasonably required in Future Electronics’ defense of
 * any claim. Future Electronics reserves the right, at its own expense, to
 * assume the exclusive defense and control of any matter otherwise subject to
 * indemnification by You and You shall not in any event settle any matter
 * without the written consent of Future Electronics.
 *
 * LIMITATION OF LIABILITY
 * Under no circumstances shall Future Electronics, nor its agents, directors,
 * employees, information providers, licensors and licensee, and affiliated
 * companies be liable for any damages, including without limitation, direct,
 * indirect, incidental, special, punitive, consequential, or other damages
 * (including without limitation lost profits, lost revenues, or similar economic
 * loss), whether in contract, tort, or otherwise, arising out of the use or
 * inability to use the materials provided as a reference design, even if we
 * are advised of the possibility thereof, nor for any claim by a third party.
 ******************************************************************************/

#ifndef STMPE610_TSDriver_H_
#define STMPE610_TSDriver_H_

#include "cpu_types.h"

#ifndef NULL
#define NULL  (void*) 0
#endif

// -- Definitions ------------------------------------------------------------

#define STMPE_ADDR                  0x41

// -- Register ---------------------------------------------------------------

// Device ID: R, 16 bits, default: 0x0811
#define STMPE_CHIP_ID               0x00

// Revision Number: R, 8 bits, default: 0x03
#define STMPE_ID_VER                0x02

// Reset Control: R/W, 8 bits, default: 0x00
//	bit 7:2 : Reserved
//	bit 1 	: Soft Reset
//  bit 0 	: Hibernate
#define STMPE_SYS_CTRL1             0x03
#define STMPE_SYS_CTRL1_HIBER       0x01
#define STMPE_SYS_CTRL1_RESET       0x02

// Clock Control: R/W, 8 bits, default: 0x0F
//  bit 7:3	: Reserved
//  bit 2		: GPIO clock off
//  bit 1 	: TSC clock off
//  bit 0		: ADC clock off
#define STMPE_SYS_CTRL2             0x04
#define STMPE_SYS_CTRL2_GPIO_OFF    0x04
#define STMPE_SYS_CTRL2_TSC_OFF     0x02
#define STMPE_SYS_CTRL2_ADC_OFF     0x01

// SPI Config: R/W, 8 bits, default: 0x01
//  bit 7:3	: Reserved
//  bit 2		: Auto addr increment
//  bit 1		: SPI clock mod1
//  bit 0		: SPI clock mod0
#define STMPE_SPI_CFG								0x08
#define STMPE_SPI_CFG_AUTO_INCR			0x04
#define STMPE_SPI_CFG_CLK_MOD1			0x02
#define STMPE_SPI_CFG_CLK_MOD0			0x01

// Interrupt Control: R/W, 8 bits, default: 0x00
// 	bit 7:3	: Reserved
//  bit 2		: IRQ pin polarity
//  bit 1		: IRQ host signal type (edge/level)
//  bit 0 	: IRQ master enable
#define STMPE_INT_CTRL              0x09
#define STMPE_INT_CTRL_POL_HIGH     0x04
#define STMPE_INT_CTRL_POL_LOW      0x00
#define STMPE_INT_CTRL_EDGE         0x02
#define STMPE_INT_CTRL_LEVEL        0x00
#define STMPE_INT_CTRL_ENABLE       0x01
#define STMPE_INT_CTRL_DISABLE      0x00

// Interrupt Enable: R/W, 8 bits, default: 0x00
//  bit 7		: GPIO IRQs
//	bit 6		: ADC IRQs
// 	bit 5		: Reserved
//	bit 4		: FIFO Empty
// 	bit 3		: FIFO Full
//	bit 2		: FIFO Overflow
//	bit 1		: FIFO equal or above threshold
//	bit 0		: Touch detection
#define STMPE_INT_EN                0x0A
#define STMPE_INT_EN_TOUCHDET       0x01
#define STMPE_INT_EN_FIFOTH         0x02
#define STMPE_INT_EN_FIFOOF         0x04
#define STMPE_INT_EN_FIFOFULL       0x08
#define STMPE_INT_EN_FIFOEMPTY      0x10
#define STMPE_INT_EN_ADC            0x40
#define STMPE_INT_EN_GPIO           0x80

// Interrupt Status: R, 8 bits, default: 0x10
//  Writing '1' to this register clears the corresponding bits.
//  bit 7		: GPIO IRQs trigged
//	bit 6		: ADC IRQs trigged
// 	bit 5		: Reserved
//	bit 4		: FIFO Empty trigged
// 	bit 3		: FIFO Full trigged
//	bit 2		: FIFO Overflowed trigged
//	bit 1		: FIFO equal or above threshold trigged
//	bit 0		: Touch detected
#define STMPE_INT_STA               0x0B
#define STMPE_INT_STA_TOUCHDET_RST  0x01
#define STMPE_INT_EN_FIFOTH_RST     0x02
#define STMPE_INT_EN_FIFOOF_RST     0x04
#define STMPE_INT_EN_FIFOFULL_RST   0x08
#define STMPE_INT_EN_FIFOEMPTY_RST  0x10
#define STMPE_INT_EN_ADC_RST        0x40
#define STMPE_INT_EN_GPIO_RST       0x80

// GPIO Interrupt Enable: R/W, 8 bits, default: 0x10
//  bit 7:0 : IRQ enable mask (1: enabled)
#define STMPE_GPIO_INT_EN						0x0C

// GPIO Interrupt Status: R, 8 bits, default: 0x00
//  bit 7:0 : IRQ status (a read clears bits)
#define STMPE_GPIO_INT_STA					0x0D

// ADC Interrupt Enable: R/W, 8 bits, default: 0x??
#define STMPE_ADC_INT_EN						0x0E

// ADC Interrupt Status: R, 8 bits, default: 0x00
#define STMPE_ADC_INT_STA						0x0F

// GPIO registers, R/W, 8 bits
#define STMPE_GPIO_SET_PIN          0x10    // GPIO set pin register
#define STMPE_GPIO_CLR_PIN          0x11    // GPIO clear pin register
#define STMPE_GPIO_DIR              0x13    // GPIO direction register
#define STMPE_GPIO_ALT_FUNCT        0x17    // Alternate function register

// ADC Control 1: R/W, 8 bits, default: 0x9C
//  bit 7		: Reserved
//	bit 6:4	: Sample time (nbr clk)
//					  000: 36, 001: 44, 010: 56, 011: 64, 100: 80,
//						101: 96, 110: 124, 111: invalid
//	bit 3		: ADC Mode (0: 10 bits, 1: 12 bits)
//	bit 2		: Reserved
//	bit 1		: Reference selection (0: External, 1: Internal)
//	bit 0		: Reserved
#define STMPE_ADC_CTRL1             0x20
#define STMPE_ADC_CTRL1_36CLK       0x00
#define STMPE_ADC_CTRL1_44CLK       0x10
#define STMPE_ADC_CTRL1_56CLK       0x20
#define STMPE_ADC_CTRL1_64CLK       0x30
#define STMPE_ADC_CTRL1_80CLK       0x40
#define STMPE_ADC_CTRL1_96CLK       0x50
#define STMPE_ADC_CTRL1_124CLK      0x60
#define STMPE_ADC_CTRL1_12BIT       0x08
#define STMPE_ADC_CTRL1_10BIT       0x00

// ADC Control 2: R/W, 8 bits, default: 0x01
//  bit 7:2	: Reserved
//	bit 1:0	: ADC clock speed
//					  00: 1.625Mhz, 01: 3.25Mhz, 10: 6.5Mhz, 11: 6.5 Mhz
#define STMPE_ADC_CTRL2             0x21
#define STMPE_ADC_CTRL2_1_625MHZ    0x00
#define STMPE_ADC_CTRL2_3_25MHZ     0x01
#define STMPE_ADC_CTRL2_6_5MHZ      0x02

// ADC Channel Data Capture: R/W, 8 bits, default: 0xFF
//  bit 7:0	: Write 1: Init data capture
//					  Read 1: Data capture completed
//						Read 0: Data capture in progress
#define STMPE_ADC_CAPT             	0x22

// ADC Channel Data: R, 16 bits, default: 0x0000
//	bit 11:0 : ADC channel data
#define STMPE_ADC_DATA_CH0         	0x30
#define STMPE_ADC_DATA_CH1         	0x32
#define STMPE_ADC_DATA_CH2         	0x34
#define STMPE_ADC_DATA_CH3         	0x36
#define STMPE_ADC_DATA_CH4         	0x38
#define STMPE_ADC_DATA_CH5         	0x3A
#define STMPE_ADC_DATA_CH6         	0x3C
#define STMPE_ADC_DATA_CH7         	0x3E

// Touchscreen Controller Setup: R/W, 8 bits, default: 0x90
//	bit 7		: TSC status (read 1: touched, read 0, no touch)
//  bit 6:4	: Tracking index
// 						000: no tracking, 001: 4, 010: 8, 011: 16
//  bit 3:1	: Operation mode (can't be written when EN = 1)
// 						000: X/Y/Z, 001: X/Y, 010: X, 011: Y, 100: Z
//  bit 0		: Enable
#define STMPE_TSC_CTRL              0x40
#define STMPE_TSC_CTRL_EN           0x01
#define STMPE_TSC_CTRL_XYZ          0x00
#define STMPE_TSC_CTRL_XY           0x01

// Touchscreen Controller Configuration: R/W, 8 bits, default: na
//	bit 7:6	: Average control (samples)
//						00: 1, 01: 2, 10: 4, 11: 8
//  bit 5:3	: Touch detect delay
// 						000: 10us, 001: 50us, 010: 100us, 011: 500us
//						100: 1ms, 101: 5ms, 110: 10ms, 111: 50ms
//  bit 2:0	: Driver setting time
// 						000: 10us, 001: 100us, 010: 500us, 011: 1ms
//						100: 5ms, 101: 10ms, 110: 50ms, 111: 100ms
#define STMPE_TSC_CFG               0x41
#define STMPE_TSC_CFG_1SAMPLE       0x00
#define STMPE_TSC_CFG_2SAMPLE       0x01
#define STMPE_TSC_CFG_4SAMPLE       0x02
#define STMPE_TSC_CFG_8SAMPLE       0x03
#define STMPE_TSC_CFG_DELAY_10US    0x00
#define STMPE_TSC_CFG_DELAY_50US    0x01
#define STMPE_TSC_CFG_DELAY_100US   0x02
#define STMPE_TSC_CFG_DELAY_500US   0x03
#define STMPE_TSC_CFG_DELAY_1MS     0x04
#define STMPE_TSC_CFG_DELAY_5MS     0x05
#define STMPE_TSC_CFG_DELAY_10MS    0x06
#define STMPE_TSC_CFG_DELAY_50MS    0x07
#define STMPE_TSC_CFG_SETTLE_10US   0x00
#define STMPE_TSC_CFG_SETTLE_100US  0x01
#define STMPE_TSC_CFG_SETTLE_500US  0x02
#define STMPE_TSC_CFG_SETTLE_1MS    0x03
#define STMPE_TSC_CFG_SETTLE_5MS    0x04
#define STMPE_TSC_CFG_SETTLE_10MS   0x05
#define STMPE_TSC_CFG_SETTLE_50MS   0x06
#define STMPE_TSC_CFG_SETTLE_100MS  0x07

// Touchscreen Window setup: R/W, 16 bits
//  bit 11:0 : Value
//  TR_X / TR_Y default: 0x0FFF
//  BL_X / BL_Y default: 0x0000
//  TR: Top Right, BL: Bottom Left
#define STMPE_TSC_WDW_TR_X					0x42
#define STMPE_TSC_WDW_TR_Y					0x44
#define STMPE_TSC_WDW_BL_X					0x46
#define STMPE_TSC_WDW_BL_Y					0x48

// Touchscreen FIFO IRQ threshold, R/W, 8 bits
//  bit 7:0	: Value
#define STMPE_FIFO_TH               0x4A

// Touchscreen FIFO Status: R/W, 8 bits, default: 0x20
//  Writing '1' to this register clears the corresponding bits.
//  bit 7		: Overflow (read 1)
//	bit 6		: Full (read 1)
// 	bit 5		: Empty (read 1)
//	bit 4		: TH trig (read 0: <, read 1: >=)
// 	bit 3:1	: Reserved
//	bit 0		: Reset (write 1: reset, write 0: out of reset)
#define STMPE_FIFO_CTRL_STA         0x4B
#define STMPE_FIFO_CTRL_STA_OFLOW   0x80
#define STMPE_FIFO_CTRL_STA_FULL    0x40
#define STMPE_FIFO_CTRL_STA_EMPTY   0x20
#define STMPE_FIFO_CTRL_STA_THTRIG  0x10

// Touchscreen FIFO Size: R, 8 bits, default: 0x00
//  Number of available samples
//  bit 7 	: Reserved
//  bit 6:0 : Value
#define STMPE_FIFO_SIZE             0x4C

// Touchscreen Data X, R, 16 bits, default: 0x0000
//  bit 11:0 : Value
#define STMPE_TSC_DATA_X            0x4D

// Touchscreen Data Y, R, 16 bits, default: 0x0000
//  bit 11:0 : Value
#define STMPE_TSC_DATA_Y            0x4F

// Touchscreen Data Z, R, 8 bits, default: 0x00
//  bit 7:0 : Value
#define STMPE_TSC_DATA_Z            0x51

// Touchscreen Data Z Fraction, R, 8 bits, default: 0x00
//  bit 7:3 : Reserved
//  bit 2:0 : Fraction (fraction part/whole part)
// 						000: 0/8, 001: 1/7, 010: 2/6, 011: 3/5
//						100: 4/4, 101: 5/3, 110: 6/2, 111: 7/1
#define STMPE_TSC_FRACTION_Z        0x56

// Touchscreen Controller Driving Channel, R/W, 8 bits, default: 0x00
//  bit 7:1 : Reserved
//  bit 0   : Drive (0: 20mA/35mA max, 1: 50mA/80mA max)
#define STMPE_TSC_I_DRIVE           0x58
#define STMPE_TSC_I_DRIVE_20MA      0x00
#define STMPE_TSC_I_DRIVE_50MA      0x01



// --- Public Functions --------------------------------------------------------

/*-------------------------------------------------------------------------*//**
  The STMPE610_Init() initialized different hardware parameters related to
  the STMPE610 advanced touchscreen controller.

  @param
		none.

  @return
    none.

  */
void STMPE610_Init();

/*-------------------------------------------------------------------------*//**
  The STMPE610_Validate_ID() reads and validate the touchscreen controller ID
  for compatibility with this driver.

  @param
		none.

  @return
    1 if ID valid, 0 if not.

  */
uint8_t STMPE610_Validate_ID();

/*-------------------------------------------------------------------------*//**
  The STMPE610_Validate_Version() reads and validate the touchscreen controller
  firmware version for compatibility with this driver.

  @param
		none.

  @return
    1 if ID valid, 0 if not.

  */
uint8_t STMPE610_Validate_Version();

/*-------------------------------------------------------------------------*//**
  The STMPE610_Buff_Empty() returns the status of the 'Empty' FIFO flag. The
  FIFO is used to store touch data.

  @param
		none.

  @return
    Status of the buffer (0: empty, 1: not empty)

  */
uint8_t STMPE610_Buff_Empty();

/*-------------------------------------------------------------------------*//**
  The STMPE610_Touched() returns the TSC status.

  @param
		none.

  @return
    TSC Status (0: no touch, 1: touched)

  */
uint8_t STMPE610_Touched();

/*-------------------------------------------------------------------------*//**
  The STMPE610_Reset_IRQ() clears all flags of the Interrupt Status register.

  @param
		none.

  @return
    none.

  */
void STMPE610_Reset_IRQ();

/*-------------------------------------------------------------------------*//**
  The STMPE610_GetPoint() reads the content of the touch data registers and
  packs it into the TS_Point data structure. It extracts the x, y and weight
  of the touch.

  @param *point
		Pointer to a TS_Point structure. See Ada28TFT_Touch.h for more details on
		TS_Point.

  @return
    none.

  */
void STMPE610_GetPoint(TS_Point *point);


#endif /* STMPE610_TSDriver_H_ */
