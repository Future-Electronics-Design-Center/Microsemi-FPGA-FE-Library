/*******************************************************************************
 * Project     : ...
 * File        : ILI9341_TFTDriver.h
 *
 * Description : This file contains the definition for a basic set of functions
 * 							 for the ILI9341 TFT LCD driver that can be found on many
 * 							 TFT displays from Adafruit.
 *
 * 							 Note: Most of the code comes from the Adafruit C++ library.
 *
 * Created on  : Jan 23, 2019
 * Author      : Frederic.Vachon  
 *
 * (c) Copyright 2019 Future Electronics - Advanced Engineering Group
 *     All rights reserved
 *
 * DISCLAIMER OF WARRANTY
 * All materials, information and services are provided “as-is” and “as-available”
 * for your use. Future Electronics disclaims all warranties of any kind, either
 * express or implied, including but not limited to, the implied warranties of
 * merchantability and fitness for a particular purpose, title, or non-infringement.
 * You acknowledge and agree that the reference designs and other such design
 * materials included herein are provided as an example only and that you will
 * exercise your own independent analysis and judgment in your use of these
 * materials. Future Electronics assumes no liability for your use of these
 * materials for your product designs.
 *
 * INDEMNIFICATION
 * You agree to indemnify, defend and hold Future Electronics and all of its
 * agents, directors, employees, information providers, licensors and licensees,
 * and affiliated companies (collectively, “Indemnified Parties”), harmless from
 * and against any and all liability and costs (including, without limitation,
 * attorneys’ fees and costs), incurred by the Indemnified Parties in connection
 * with any claim arising out of any breach by You of these Terms and Conditions 
 * of Use or any representations or warranties made by You herein. You will
 * cooperate as fully as reasonably required in Future Electronics’ defense of
 * any claim. Future Electronics reserves the right, at its own expense, to
 * assume the exclusive defense and control of any matter otherwise subject to
 * indemnification by You and You shall not in any event settle any matter
 * without the written consent of Future Electronics.
 *
 * LIMITATION OF LIABILITY
 * Under no circumstances shall Future Electronics, nor its agents, directors,
 * employees, information providers, licensors and licensee, and affiliated
 * companies be liable for any damages, including without limitation, direct,
 * indirect, incidental, special, punitive, consequential, or other damages
 * (including without limitation lost profits, lost revenues, or similar economic
 * loss), whether in contract, tort, or otherwise, arising out of the use or
 * inability to use the materials provided as a reference design, even if we
 * are advised of the possibility thereof, nor for any claim by a third party.
 ******************************************************************************/

#ifndef ILI9341_H_
#define ILI9341_H_

#include "cpu_types.h"

#ifndef NULL
#define NULL  (void*) 0
#endif

// -- Definitions ------------------------------------------------------------

#define ILI9341_TFT_HEIGHT 	320
#define ILI9341_TFT_WIDTH  	240

#define ILI9341_NOP         0x00
#define ILI9341_SWRESET     0x01
#define ILI9341_RDDID       0x04
#define ILI9341_RDDST       0x09

#define ILI9341_SLPIN       0x10
#define ILI9341_SLPOUT      0x11
#define ILI9341_PTLON       0x12
#define ILI9341_NORON       0x13

#define ILI9341_RDMODE      0x0A
#define ILI9341_RDMADCTL    0x0B
#define ILI9341_RDPIXFMT    0x0C
#define ILI9341_RDIMGFMT    0x0D
#define ILI9341_RDSELFDIAG  0x0F

#define ILI9341_INVOFF      0x20
#define ILI9341_INVON       0x21
#define ILI9341_GAMMASET    0x26
#define ILI9341_DISPOFF     0x28
#define ILI9341_DISPON      0x29

#define ILI9341_CASET       0x2A
#define ILI9341_PASET       0x2B
#define ILI9341_RAMWR       0x2C
#define ILI9341_RAMRD       0x2E

#define ILI9341_PTLAR       0x30
#define ILI9341_MADCTL      0x36
#define ILI9341_VSCRSADD    0x37
#define ILI9341_PIXFMT      0x3A

#define ILI9341_FRMCTR1     0xB1
#define ILI9341_FRMCTR2     0xB2
#define ILI9341_FRMCTR3     0xB3
#define ILI9341_INVCTR      0xB4
#define ILI9341_DFUNCTR     0xB6

#define ILI9341_PWCTR1      0xC0
#define ILI9341_PWCTR2      0xC1
#define ILI9341_PWCTR3      0xC2
#define ILI9341_PWCTR4      0xC3
#define ILI9341_PWCTR5      0xC4
#define ILI9341_VMCTR1      0xC5
#define ILI9341_VMCTR2      0xC7

#define ILI9341_RDID1       0xDA
#define ILI9341_RDID2       0xDB
#define ILI9341_RDID3       0xDC
#define ILI9341_RDID4       0xD3

#define ILI9341_GMCTRP1     0xE0
#define ILI9341_GMCTRN1     0xE1

// Color definitions
#define ILI9341_BLACK       0x0000      /*   0,   0,   0 */
#define ILI9341_NAVY        0x000F      /*   0,   0, 128 */
#define ILI9341_DARKGREEN   0x03E0      /*   0, 128,   0 */
#define ILI9341_DARKCYAN    0x03EF      /*   0, 128, 128 */
#define ILI9341_MAROON      0x7800      /* 128,   0,   0 */
#define ILI9341_PURPLE      0x780F      /* 128,   0, 128 */
#define ILI9341_OLIVE       0x7BE0      /* 128, 128,   0 */
#define ILI9341_LIGHTGREY   0xC618      /* 192, 192, 192 */
#define ILI9341_DARKGREY    0x7BEF      /* 128, 128, 128 */
#define ILI9341_BLUE        0x001F      /*   0,   0, 255 */
#define ILI9341_GREEN       0x07E0      /*   0, 255,   0 */
#define ILI9341_CYAN        0x07FF      /*   0, 255, 255 */
#define ILI9341_RED         0xF800      /* 255,   0,   0 */
#define ILI9341_MAGENTA     0xF81F      /* 255,   0, 255 */
#define ILI9341_YELLOW      0xFFE0      /* 255, 255,   0 */
#define ILI9341_WHITE       0xFFFF      /* 255, 255, 255 */
#define ILI9341_ORANGE      0xFD20      /* 255, 165,   0 */
#define ILI9341_GREENYELLOW 0xAFE5      /* 173, 255,  47 */
#define ILI9341_PINK        0xF81F

// --- Public Functions --------------------------------------------------------

/*-------------------------------------------------------------------------*//**
  The ILI9341_Init() initialized different parameters of the video driver for
  proper image display on the TFT. If activated, backlight will also fix to the
  provided value.

  @param intensity
    Initial value for backlight intensity (0-100)

  @return
    none.

  */
void ILI9341_Init(uint8_t intensity);

/*-------------------------------------------------------------------------*//**
  The ILI9341_TFT_fillrect() draws a filled rectangle.

  @param xpt
    X-axis coordinate of the lower-left corner (pixel unit)

  @param ypt
    Y-axis coordinate of the lower-left corner (pixel unit)

  @param width
    Width (X-axis) of the rectangle (pixel unit)

  @param height
    Height (Y-axis) of the rectangle (pixel unit)

  @param colour
    Filling colour of the rectangle

  @return
    none.

  */
void ILI9341_TFT_fillrect(int16_t xpt, int16_t ypt, int16_t width,
                          int16_t height, uint16_t colour);

/*-------------------------------------------------------------------------*//**
  The ILI9341_TFT_fillScreen() paints the screen with the required colour.

  @param colour
    Filling colour of the rectangle

  @return
    none.

  */
void ILI9341_TFT_fillScreen(uint16_t colour);

/*-------------------------------------------------------------------------*//**
  The ILI9341_TFT_fastVLine() draws a vertical line of the required colour.

  @param pos_x
    X-axis coordinate of the lower end of the line (pixel unit)

  @param pos_y
    Y-axis coordinate of the lower end of the line (pixel unit)

  @param height
    Height (Y-axis) of the line (pixel unit)

  @param colour
    Colour of the line

  @return
    none.

  */
void ILI9341_TFT_fastVLine(int16_t pos_x, int16_t pos_y, int16_t height,
                           int16_t colour);

/*-------------------------------------------------------------------------*//**
  The ILI9341_TFT_fastHLine() draws an horizontal line of the required colour.

  @param pos_x
    X-axis coordinate of the left end of the line (pixel unit)

  @param pos_y
    Y-axis coordinate of the left end of the line (pixel unit)

  @param height
    Width (X-axis) of the line (pixel unit)

  @param colour
    Colour of the line

  @return
    none.

  */
void ILI9341_TFT_fastHLine(int16_t pos_x, int16_t pos_y, int16_t width,
													 int16_t colour);

/*-------------------------------------------------------------------------*//**
  The ILI9341_TFT_drawPixel() draws a pixel of the required colour.

  @param xPt
    X-axis coordinate of the pixel (pixel unit)

  @param yPt
    Y-axis coordinate of the pixel (pixel unit)

  @param colour
    Colour of the pixel

  @return
    none.

  */
void ILI9341_TFT_drawPixel(int16_t xPt, int16_t yPt, uint16_t colour);

/*-------------------------------------------------------------------------*//**
  The ILI9341_TFT_drawCircle() draws a circle of the required colour.

  @param x0
    X-axis coordinate of the center of the circle (pixel unit)

  @param y0
    Y-axis coordinate of the center of the circle (pixel unit)

  @param radius
    Radius (pixel unit)

  @param colour
    Colour of the circle

  @return
    none.

  */
void ILI9341_TFT_drawCircle(int16_t x0, int16_t y0, int16_t radius,
                            uint16_t colour);

/*-------------------------------------------------------------------------*//**
  The ILI9341_TFT_drawLine() draws a line of the required colour.

  @param x0
    X-axis coordinate of one end of the line (pixel unit)

  @param y0
    Y-axis coordinate of one end of the line (pixel unit)

  @param x1
    X-axis coordinate of the other end of the line (pixel unit)

  @param y1
    Y-axis coordinate of the other end of the line (pixel unit)

  @param colour
    Colour of the line

  @return
    none.

  */
void ILI9341_TFT_drawLine(int16_t x0, int16_t y0, int16_t x1, int16_t y1,
                          uint16_t colour);


/*-------------------------------------------------------------------------*//**
  The ILI9341_TFT_backlite() is used to set the PWM associated with the TFT
  backlight to the required duty cycle to provide an intensity from 0 to 100%.

  @param intensity
    Value for backlight intensity (0-100)

  @return
    none.

  */
void ILI9341_TFT_backlite(uint8_t intensity);


#endif /* ILI9341_H_ */
