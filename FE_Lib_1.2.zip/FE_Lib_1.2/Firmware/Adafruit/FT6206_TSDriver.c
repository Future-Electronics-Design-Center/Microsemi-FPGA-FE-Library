/*******************************************************************************
 * Project     : ...
 * File        : FT6206_TSDriver.c
 *
 * Description : This file contains low level driver for the FT6206 Capacitive
 *               touch screen controller that can be found on the 1947 display
 *               from Adafruit. It uses an I2C interface to communicate with its
 *               host.
 *
 * Created on  : Jan 23, 2019
 * Author      : Frederic.Vachon  
 *
 * (c) Copyright 2019 Future Electronics - Advanced Engineering Group
 *     All rights reserved
 *
 * DISCLAIMER OF WARRANTY
 * All materials, information and services are provided “as-is” and “as-available”
 * for your use. Future Electronics disclaims all warranties of any kind, either
 * express or implied, including but not limited to, the implied warranties of
 * merchantability and fitness for a particular purpose, title, or non-infringement.
 * You acknowledge and agree that the reference designs and other such design
 * materials included herein are provided as an example only and that you will
 * exercise your own independent analysis and judgment in your use of these
 * materials. Future Electronics assumes no liability for your use of these
 * materials for your product designs.
 *
 * INDEMNIFICATION
 * You agree to indemnify, defend and hold Future Electronics and all of its
 * agents, directors, employees, information providers, licensors and licensees,
 * and affiliated companies (collectively, “Indemnified Parties”), harmless from
 * and against any and all liability and costs (including, without limitation,
 * attorneys’ fees and costs), incurred by the Indemnified Parties in connection
 * with any claim arising out of any breach by You of these Terms and Conditions 
 * of Use or any representations or warranties made by You herein. You will
 * cooperate as fully as reasonably required in Future Electronics’ defense of
 * any claim. Future Electronics reserves the right, at its own expense, to
 * assume the exclusive defense and control of any matter otherwise subject to
 * indemnification by You and You shall not in any event settle any matter
 * without the written consent of Future Electronics.
 *
 * LIMITATION OF LIABILITY
 * Under no circumstances shall Future Electronics, nor its agents, directors,
 * employees, information providers, licensors and licensee, and affiliated
 * companies be liable for any damages, including without limitation, direct,
 * indirect, incidental, special, punitive, consequential, or other damages
 * (including without limitation lost profits, lost revenues, or similar economic
 * loss), whether in contract, tort, or otherwise, arising out of the use or
 * inability to use the materials provided as a reference design, even if we
 * are advised of the possibility thereof, nor for any claim by a third party.
 ******************************************************************************/

#include "Ada28TFT_Touch.h"
#include "FT6206_TSDriver.h"
#include "core_i2c.h"

// -- Definitions --------------------------------------------------------------

extern i2c_instance_t g_i2c_ADA28;

// --- Private functions -------------------------------------------------------

uint8_t FT6206_Read_Register8(uint8_t addr) {

  uint8_t rx_buffer;
  i2c_status_t status;

  I2C_write_read(ADA28_I2C, FT62XX_ADDR, &addr, 1, &rx_buffer, 1, I2C_RELEASE_BUS);
  status = I2C_wait_complete(ADA28_I2C, I2C_NO_TIMEOUT);

	return rx_buffer;
}


void FT6206_Write_Register8(uint8_t addr, uint8_t val) {

  i2c_status_t status;

  I2C_write(ADA28_I2C, addr, &val, 1, I2C_RELEASE_BUS);
  status = I2C_wait_complete(ADA28_I2C, I2C_NO_TIMEOUT);
}


void FT6206_Read_Data(TS_Point *point) {

  uint8_t rx_buffer[6];
  uint8_t tx_buffer;
  i2c_status_t status;
  
  tx_buffer = FT62XX_P1_XH;
  I2C_write_read(ADA28_I2C, FT62XX_ADDR, &tx_buffer, 1U, rx_buffer, 6U, I2C_RELEASE_BUS);
  status = I2C_wait_complete(ADA28_I2C, I2C_NO_TIMEOUT);

  point->x = rx_buffer[0] & 0x0F;
  point->x <<= 8;
  point->x |= rx_buffer[1];
  point->id = rx_buffer[2] >> 4;
  point->y = rx_buffer[2] & 0x0F;
  point->y <<= 8;
  point->y |= rx_buffer[3];
  point->w = rx_buffer[4];
  point->area = rx_buffer[5] >> 4;
}


// --- Public Functions --------------------------------------------------------

uint8_t FT6206_Init() {

  if (FT6206_ValidateModel()) {
    // change Threshhold to be higher/lower
    FT6206_Write_Register8(FT62XX_TH_GROUP, FT62XX_TH_GROUP_DEFAULT);
    return 1;
  }
	return 0;
}


uint8_t FT6206_ValidateID() {

  uint8_t result = FT6206_Read_Register8(FT62XX_FOCALTECH_ID);

  if (result != FT62XX_FOCALTECH_ID_PANEL) return 0;
  return 1;
}


uint8_t FT6206_ValidateModel() {

  uint8_t result = FT6206_Read_Register8(FT62XX_CIPHER);

  if ((result != FT62XX_CIPHER_FT6206) && (result != FT62XX_CIPHER_FT6236)) return 0;
  return 1;
}


void FT6206_IRQ() {
	I2C_isr(ADA28_I2C);
}


uint8_t FT6206_Touched() {

  uint8_t n = FT6206_Read_Register8(FT62XX_TD_STATUS);

  if (n > 2) {
    n = 0;
  }
  return n;
}


void FT6206_GetPoint(TS_Point *point) {
	FT6206_Read_Data(point);
}
