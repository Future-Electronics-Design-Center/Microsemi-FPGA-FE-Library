/*******************************************************************************
 * Project     : ...
 * File        : STMPE610_TSDriver.c
 *
 * Description : This file contains low level driver for the STMPE610 Resistive
 *               touch screen controller that can be found on the 1651 display
 *               from Adafruit. It uses a SPI interface to communicate with its
 *               host.
 *
 * Created on  : Jan 22, 2019
 * Author      : Frederic.Vachon  
 *
 * (c) Copyright 2019 Future Electronics - Advanced Engineering Group
 *     All rights reserved
 *
 * DISCLAIMER OF WARRANTY
 * All materials, information and services are provided “as-is” and “as-available”
 * for your use. Future Electronics disclaims all warranties of any kind, either
 * express or implied, including but not limited to, the implied warranties of
 * merchantability and fitness for a particular purpose, title, or non-infringement.
 * You acknowledge and agree that the reference designs and other such design
 * materials included herein are provided as an example only and that you will
 * exercise your own independent analysis and judgment in your use of these
 * materials. Future Electronics assumes no liability for your use of these
 * materials for your product designs.
 *
 * INDEMNIFICATION
 * You agree to indemnify, defend and hold Future Electronics and all of its
 * agents, directors, employees, information providers, licensors and licensees,
 * and affiliated companies (collectively, “Indemnified Parties”), harmless from
 * and against any and all liability and costs (including, without limitation,
 * attorneys’ fees and costs), incurred by the Indemnified Parties in connection
 * with any claim arising out of any breach by You of these Terms and Conditions 
 * of Use or any representations or warranties made by You herein. You will
 * cooperate as fully as reasonably required in Future Electronics’ defense of
 * any claim. Future Electronics reserves the right, at its own expense, to
 * assume the exclusive defense and control of any matter otherwise subject to
 * indemnification by You and You shall not in any event settle any matter
 * without the written consent of Future Electronics.
 *
 * LIMITATION OF LIABILITY
 * Under no circumstances shall Future Electronics, nor its agents, directors,
 * employees, information providers, licensors and licensee, and affiliated
 * companies be liable for any damages, including without limitation, direct,
 * indirect, incidental, special, punitive, consequential, or other damages
 * (including without limitation lost profits, lost revenues, or similar economic
 * loss), whether in contract, tort, or otherwise, arising out of the use or
 * inability to use the materials provided as a reference design, even if we
 * are advised of the possibility thereof, nor for any claim by a third party.
 ******************************************************************************/

#include "Ada28TFT_Touch.h"
#include "STMPE610_TSDriver.h"
#include "core_gpio.h"
#include "core_spi.h"

// -- Definitions --------------------------------------------------------------

#define SPI_WRITE_OP			0x00
#define SPI_READ_OP				0x80

extern gpio_instance_t g_gpio_ADA28;
extern spi_instance_t g_spi_ADA28;

// --- Private functions -------------------------------------------------------

void STMPE610_CS_Set() {
	GPIO_set_output(ADA28_GPIO, ADA28_CS, ADA28_CS_TS);
}


void STMPE610_CS_Clear() {
	GPIO_set_output(ADA28_GPIO, ADA28_CS, ADA28_CS_TFT);
}


void STMPE610_Write (uint8_t data) {
	SPI_transfer_frame(ADA28_SPI, data);
}


uint8_t STMPE610_Read_Register8 (uint8_t reg) {

	uint8_t master_rx = 0x00;

	STMPE610_CS_Set();
	SPI_set_slave_select(ADA28_SPI, SPI_SLAVE_1);
	master_rx = SPI_transfer_frame(ADA28_SPI, SPI_READ_OP | reg);
	master_rx = SPI_transfer_frame(ADA28_SPI, 0x0);
	SPI_clear_slave_select(ADA28_SPI, SPI_SLAVE_1);
	STMPE610_CS_Clear();

	return master_rx;
}


void STMPE610_Write_Register8 (uint8_t reg,	uint8_t data) {

	STMPE610_CS_Set();
	SPI_set_slave_select(ADA28_SPI, SPI_SLAVE_1);
	SPI_transfer_frame(ADA28_SPI, SPI_WRITE_OP | reg);
	SPI_transfer_frame(ADA28_SPI, data);
	SPI_clear_slave_select(ADA28_SPI, SPI_SLAVE_1);
	STMPE610_CS_Clear();
}


// --- Public Functions --------------------------------------------------------

void STMPE610_Init() {

	STMPE610_Write_Register8(STMPE_SYS_CTRL1, STMPE_SYS_CTRL1_RESET);
	for (volatile uint16_t delay = 0xFFFF; delay > 0; delay--);
	STMPE610_Write_Register8(STMPE_SYS_CTRL2, 0x00); // Turn on Clocks

	// IRQn setup
	STMPE610_Write_Register8(STMPE_INT_CTRL, STMPE_INT_CTRL_POL_LOW | STMPE_INT_CTRL_ENABLE);
	STMPE610_Write_Register8(STMPE_INT_EN, STMPE_INT_EN_TOUCHDET);
	STMPE610_Write_Register8(STMPE_INT_STA, 0xFF); // reset all ints

	// ADC setup
	STMPE610_Write_Register8(STMPE_ADC_CTRL1, STMPE_ADC_CTRL1_96CLK | STMPE_ADC_CTRL1_10BIT);
	for (volatile uint16_t delay = 0xFFFF; delay > 0; delay--);
	STMPE610_Write_Register8(STMPE_ADC_CTRL2, STMPE_ADC_CTRL2_6_5MHZ);

	// FIFO setup
	STMPE610_Write_Register8(STMPE_FIFO_TH, 0x01);					// Threshold = 1
	STMPE610_Write_Register8(STMPE_FIFO_CTRL_STA, 0x01);		// reset
	STMPE610_Write_Register8(STMPE_FIFO_CTRL_STA, 0x00);   	// clear reset

	// Touchscreen setup
	STMPE610_Write_Register8(STMPE_TSC_CTRL, (STMPE_TSC_CTRL_XYZ << 1) | STMPE_TSC_CTRL_EN); // XYZ and enable!
	STMPE610_Write_Register8(STMPE_TSC_CFG, (STMPE_TSC_CFG_4SAMPLE << 6) | (STMPE_TSC_CFG_DELAY_1MS << 3) | STMPE_TSC_CFG_SETTLE_5MS);
	STMPE610_Write_Register8(STMPE_TSC_FRACTION_Z, 0x6);
	STMPE610_Write_Register8(STMPE_TSC_I_DRIVE, STMPE_TSC_I_DRIVE_20MA);

}


uint8_t STMPE610_Validate_ID() {

	uint16_t IDNumber = 0;
	IDNumber = STMPE610_Read_Register8(STMPE_CHIP_ID);
	IDNumber <<= 8;
	IDNumber |= STMPE610_Read_Register8(1);
	if (IDNumber == 0x0811) {
		return 1;
	}
	return 0;
}


uint8_t STMPE610_Validate_Version() {
	if (STMPE610_Read_Register8(STMPE_ID_VER) == 0x03) {
		return 1;
	}
	return 0;
}


uint8_t STMPE610_Buff_Empty() {
	return (STMPE610_Read_Register8(STMPE_FIFO_CTRL_STA) & STMPE_FIFO_CTRL_STA_EMPTY);
}


uint8_t STMPE610_Touched() {
	return (STMPE610_Read_Register8(STMPE_TSC_CTRL) & 0x80);
}


void STMPE610_Reset_IRQ() {
	STMPE610_Write_Register8(STMPE_INT_STA, 0xFF);  // Reset all IRQs
}


void STMPE610_GetPoint(TS_Point *point) {

	uint8_t data[4];

	while(!STMPE610_Buff_Empty()) {
		for (uint8_t loop = 0; loop < 4; loop++) {
			data[loop]= STMPE610_Read_Register8(0xD7);
		}

		point->x = data[0];
		point->x <<= 4;
		point->x |= (data[1] >> 4);
		point->y = data[1] & 0x0F;
		point->y <<= 8;
		point->y |= data[2];
		point->w = data[3];
	}
	point->area = 0;
	point->id = 0;

	if(STMPE610_Buff_Empty()) STMPE610_Reset_IRQ();
}





