/*******************************************************************************
 * Project     : ...
 * File        : Ada28TFT_Touch.c
 *
 * Description : This file contains a definition for a basic TFT touchscreen
 * 							 and support two models from the Adafruit 2.8" TFT touchscreen
 * 							 series: the 1651 Resistive touch and the 1947 Capacitive touch.
 *
 * 							 By setting ADA_BACKLITE_CTRL constant to 1 will activate the
 * 							 capability to set the TFT backlight intensity. Ensure to close
 * 							 the appropriate jumper behind your display.
 *
 * 							 By using the ADA28_SelectTFT function in your main program, the
 * 							 driver will setup itself properly to interact with the detected
 * 							 dislay.
 *
 * Created on  : Jan 23, 2019
 * Author      : Frederic.Vachon  
 *
 * (c) Copyright 2019 Future Electronics - Advanced Engineering Group
 *     All rights reserved
 *
 * DISCLAIMER OF WARRANTY
 * All materials, information and services are provided “as-is” and “as-available”
 * for your use. Future Electronics disclaims all warranties of any kind, either
 * express or implied, including but not limited to, the implied warranties of
 * merchantability and fitness for a particular purpose, title, or non-infringement.
 * You acknowledge and agree that the reference designs and other such design
 * materials included herein are provided as an example only and that you will
 * exercise your own independent analysis and judgment in your use of these
 * materials. Future Electronics assumes no liability for your use of these
 * materials for your product designs.
 *
 * INDEMNIFICATION
 * You agree to indemnify, defend and hold Future Electronics and all of its
 * agents, directors, employees, information providers, licensors and licensees,
 * and affiliated companies (collectively, “Indemnified Parties”), harmless from
 * and against any and all liability and costs (including, without limitation,
 * attorneys’ fees and costs), incurred by the Indemnified Parties in connection
 * with any claim arising out of any breach by You of these Terms and Conditions 
 * of Use or any representations or warranties made by You herein. You will
 * cooperate as fully as reasonably required in Future Electronics’ defense of
 * any claim. Future Electronics reserves the right, at its own expense, to
 * assume the exclusive defense and control of any matter otherwise subject to
 * indemnification by You and You shall not in any event settle any matter
 * without the written consent of Future Electronics.
 *
 * LIMITATION OF LIABILITY
 * Under no circumstances shall Future Electronics, nor its agents, directors,
 * employees, information providers, licensors and licensee, and affiliated
 * companies be liable for any damages, including without limitation, direct,
 * indirect, incidental, special, punitive, consequential, or other damages
 * (including without limitation lost profits, lost revenues, or similar economic
 * loss), whether in contract, tort, or otherwise, arising out of the use or
 * inability to use the materials provided as a reference design, even if we
 * are advised of the possibility thereof, nor for any claim by a third party.
 ******************************************************************************/

#include "hw_platform.h"
#include "core_gpio.h"
#include "core_spi.h"
#include "core_i2c.h"
#include "core_pwm.h"

#include "Ada28TFT_Touch.h"
#include "ILI9341_TFTDriver.h"
#include "STMPE610_TSDriver.h"
#include "FT6206_TSDriver.h"

// -- Definitions --------------------------------------------------------------

uint8_t               g_TFT_Model;

gpio_instance_t 			g_gpio_ADA28;
spi_instance_t 				g_spi_ADA28;
i2c_instance_t       	g_i2c_ADA28;
pwm_instance_t				g_pwm_ADA28;

// --- Private functions -------------------------------------------------------

void Delay(int milliseconds) {
	int i = milliseconds * (MMIO_CLK_FREQ / 2000);
	while (i!=0) {
		i--;
	}
}

// --- Public Functions --------------------------------------------------------

void ADA28_Init(addr_t interface_addr) {

	i2c_clock_divider_t value;

  GPIO_init(ADA28_GPIO,
  					interface_addr | ADA28_GPIO_ADDR,
						GPIO_APB_32_BITS_BUS);
  SPI_init(ADA28_SPI,
  				 interface_addr | ADA28_SPI_ADDR,
					 8);

  // SCL: 10-400KHz
  if (MMIO_CLK_FREQ < 50000000UL) {
  	value = I2C_PCLK_DIV_160;
  } else if (MMIO_CLK_FREQ < 100000000UL) {
  	value = I2C_PCLK_DIV_256;
  } else {
  	value = I2C_PCLK_DIV_960;
  }

	I2C_init(ADA28_I2C,
           interface_addr | ADA28_I2C_ADDR,
					 ADA28_I2C_DUMMY_ADDR,
					 value);

	#if ADA_BACKLITE_CTRL
		PWM_init(ADA28_PWM,
						 interface_addr | ADA28_PWM_ADDR,
						 20,
						 ADA28_TFT_BL_CYCLE - 1);
	#endif

	SPI_configure_master_mode(ADA28_SPI);

	ADA28_Reset();
}


uint8_t ADA28_SelectTFT() {

  if (STMPE610_Validate_ID()) {
    g_TFT_Model = ADA28_1651;
    return 1;
  } else if (FT6206_ValidateID()) {
    g_TFT_Model = ADA28_1947;
    return 2;
  }
  return 0;
}


void ADA28_Config(uint8_t intensity) {

	// Init TFT IC
	ILI9341_Init(intensity);

	// Init Touch IC
	if (ADA28_MODEL == ADA28_1651) STMPE610_Init();
	if (ADA28_MODEL == ADA28_1947) FT6206_Init();
}


void ADA28_Reset() {
	GPIO_set_output(ADA28_GPIO, ADA28_RSTn, ADA28_RSTn_ON);
	Delay(10);
	GPIO_set_output(ADA28_GPIO, ADA28_RSTn, ADA28_RSTn_OFF);
	Delay(310);
}


void ADA28_TFT_fillrect(int16_t xpt, int16_t ypt, int16_t width,
                        int16_t height, uint16_t colour) {
	ILI9341_TFT_fillrect(xpt, ypt, width, height, colour);
}


void ADA28_TFT_fillScreen(uint16_t colour) {
	ILI9341_TFT_fillScreen(colour);
}


void ADA28_TFT_fastVLine(int16_t pos_x, int16_t pos_y, int16_t height,
                         int16_t colour) {
	ILI9341_TFT_fastVLine(pos_x, pos_y, height, colour);
}


void ADA28_TFT_fastHLine(int16_t pos_x, int16_t pos_y, int16_t width,
                         int16_t colour) {
	ILI9341_TFT_fastHLine(pos_x, pos_y, width, colour);
}


void ADA28_TFT_drawPixel(int16_t xPt, int16_t yPt, uint16_t colour) {
	ILI9341_TFT_drawPixel(xPt, yPt, colour);
}


void ADA28_TFT_drawCircle(int16_t x0, int16_t y0, int16_t radius,
                          uint16_t color) {
	ILI9341_TFT_drawCircle(x0, y0, radius, color);
}


void ADA28_TFT_drawLine(int16_t x0, int16_t y0, int16_t x1, int16_t y1,
                        uint16_t color) {
	ILI9341_TFT_drawLine(x0, y0, x1, y1, color);
}


void ADA28_TFT_SetBacklight(uint8_t intensity) {
	ILI9341_TFT_backlite(intensity);
}


void ADA28_TS_ResetIRQ() {
  if (ADA28_MODEL == ADA28_1651) STMPE610_Reset_IRQ();
}


void ADA28_TS_I2CIRQ() {
  FT6206_IRQ();
}


uint8_t ADA28_TS_Touched() {
  if (ADA28_MODEL == ADA28_1651) return STMPE610_Touched();
  if (ADA28_MODEL == ADA28_1947) return FT6206_Touched();
  return 0;
}


void ADA28_TS_GetPoint(TS_Point *point) {
  if (g_TFT_Model == ADA28_1651) STMPE610_GetPoint(point);
  if (g_TFT_Model == ADA28_1947) FT6206_GetPoint(point);
}




