/*******************************************************************************
 * Project     : ...
 * File        : Pan9320.h
 *
 * Description : This file contains a definition for a basic Wifi module
 *               interface. Normal operation is to keep the Wifi module in
 *               Reset state. Use PAN_Enable function to active it.
 *
 * Created on  : Jun 18, 2018
 * Author      : Frederic.Vachon  
 *
 * (c) Copyright 2018 Future Electronics - Advanced Engineering Group 
 *     All rights reserved
 *
 * DISCLAIMER OF WARRANTY
 * All materials, information and services are provided “as-is” and “as-available”
 * for your use. Future Electronics disclaims all warranties of any kind, either
 * express or implied, including but not limited to, the implied warranties of
 * merchantability and fitness for a particular purpose, title, or non-infringement.
 * You acknowledge and agree that the reference designs and other such design
 * materials included herein are provided as an example only and that you will
 * exercise your own independent analysis and judgment in your use of these
 * materials. Future Electronics assumes no liability for your use of these
 * materials for your product designs.
 *
 * INDEMNIFICATION
 * You agree to indemnify, defend and hold Future Electronics and all of its
 * agents, directors, employees, information providers, licensors and licensees,
 * and affiliated companies (collectively, “Indemnified Parties”), harmless from
 * and against any and all liability and costs (including, without limitation,
 * attorneys’ fees and costs), incurred by the Indemnified Parties in connection
 * with any claim arising out of any breach by You of these Terms and Conditions 
 * of Use or any representations or warranties made by You herein. You will
 * cooperate as fully as reasonably required in Future Electronics’ defense of
 * any claim. Future Electronics reserves the right, at its own expense, to
 * assume the exclusive defense and control of any matter otherwise subject to
 * indemnification by You and You shall not in any event settle any matter
 * without the written consent of Future Electronics.
 *
 * LIMITATION OF LIABILITY
 * Under no circumstances shall Future Electronics, nor its agents, directors,
 * employees, information providers, licensors and licensee, and affiliated
 * companies be liable for any damages, including without limitation, direct,
 * indirect, incidental, special, punitive, consequential, or other damages
 * (including without limitation lost profits, lost revenues, or similar economic
 * loss), whether in contract, tort, or otherwise, arising out of the use or
 * inability to use the materials provided as a reference design, even if we
 * are advised of the possibility thereof, nor for any claim by a third party.
 ******************************************************************************/
#ifndef PAN9320_H_
#define PAN9320_H_

#include "cpu_types.h"

#ifndef NULL
#define NULL  (void*) 0
#endif

// -- Definitions ------------------------------------------------------------

// --- Public Functions --------------------------------------------------------

/*-------------------------------------------------------------------------*//**
  The PAN_Init() initialized the different hardware drivers related to the
  Panasonic Wi-Fi module: UARTs for command/data and GPIOs.

  @param interface_addr
    The base address of the interface based on the FPGA memory map. This value
    is usually a 32 bits HEX value (ie 0x6000 2000) with the 12 bits LSB
    being reserved for the interface.

  @return
    none.

  */
void PAN_Init(addr_t interface_addr);

/*-------------------------------------------------------------------------*//**
  The PAN_Disable() function is used to disable the Wi-Fi module. The module
  is simply kept in "reset" state.

  @param
    none.

  @return
    none.

  */
void PAN_Disable();

/*-------------------------------------------------------------------------*//**
  The PAN_Enable() function is used to enable the Wi-Fi module from its
  previous "reset" state.

  @param
    none.

  @return
    none.

  */
void PAN_Enable();

/*-------------------------------------------------------------------------*//**
  The PAN_Restart() function is used to send a "restart" command to the
  module.

  @param
    none.

  @return
    none.

  */
void PAN_Restart();

/*-------------------------------------------------------------------------*//**
  The PAN_Wakeup() function is used to wake-up the module after it has
  received a shut-off command.

  @param
    none.

  @return
    none.

  */
void PAN_Wakeup();

/*-------------------------------------------------------------------------*//**
  The PAN_Config_NetCat() function is used to configure the data tunneling
  using Netcat service. The different settings can be modified in the
  string commands of the C module.

  @param
    none.

  @return
    none.

  */
void PAN_Config_NetCat();

/*-------------------------------------------------------------------------*//**
  The PAN_ReceiveData() function is used to read data received on the serial
  channel (Netcat).

  @param rx_data
    A pointer to a buffer where the received data will be copied.

  @return size_t
    The number of bytes copied into the receive buffer.

  */
size_t PAN_ReceiveData(uint8_t *rx_data);

/*-------------------------------------------------------------------------*//**
  The PAN_SendData() function is used to send data using the data serial
  channel (Netcat).

  @param tx_data
    A pointer to a buffer where the data to be transmit was copied.

  @param tx_size
    The number of bytes copied into the transmit buffer.

  @return
    none.

  */
void PAN_SendData(uint8_t *tx_data, size_t tx_size);


#endif /* PAN9320_H_ */
