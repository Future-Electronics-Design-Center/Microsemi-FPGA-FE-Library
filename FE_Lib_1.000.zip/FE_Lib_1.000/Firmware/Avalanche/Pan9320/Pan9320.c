/*******************************************************************************
 * Project     : PF_MiV_OTB_Morse
 * File        : Pan9320.c
 *
 * Description : This file contains a definition for a basic Wifi module
 *               interface. Normal operation is to keep the Wifi module in
 *               Reset state. Use PAN_Enable function to active it.
 *
 * Created on  : Jun 18, 2018
 * Author      : Frederic.Vachon  
 *
 * (c) Copyright 2018 Future Electronics - Advanced Engineering Group 
 *     All rights reserved
 *
 * DISCLAIMER OF WARRANTY
 * All materials, information and services are provided “as-is” and “as-available”
 * for your use. Future Electronics disclaims all warranties of any kind, either
 * express or implied, including but not limited to, the implied warranties of
 * merchantability and fitness for a particular purpose, title, or non-infringement.
 * You acknowledge and agree that the reference designs and other such design
 * materials included herein are provided as an example only and that you will
 * exercise your own independent analysis and judgment in your use of these
 * materials. Future Electronics assumes no liability for your use of these
 * materials for your product designs.
 *
 * INDEMNIFICATION
 * You agree to indemnify, defend and hold Future Electronics and all of its
 * agents, directors, employees, information providers, licensors and licensees,
 * and affiliated companies (collectively, “Indemnified Parties”), harmless from
 * and against any and all liability and costs (including, without limitation,
 * attorneys’ fees and costs), incurred by the Indemnified Parties in connection
 * with any claim arising out of any breach by You of these Terms and Conditions 
 * of Use or any representations or warranties made by You herein. You will
 * cooperate as fully as reasonably required in Future Electronics’ defense of
 * any claim. Future Electronics reserves the right, at its own expense, to
 * assume the exclusive defense and control of any matter otherwise subject to
 * indemnification by You and You shall not in any event settle any matter
 * without the written consent of Future Electronics.
 *
 * LIMITATION OF LIABILITY
 * Under no circumstances shall Future Electronics, nor its agents, directors,
 * employees, information providers, licensors and licensee, and affiliated
 * companies be liable for any damages, including without limitation, direct,
 * indirect, incidental, special, punitive, consequential, or other damages
 * (including without limitation lost profits, lost revenues, or similar economic
 * loss), whether in contract, tort, or otherwise, arising out of the use or
 * inability to use the materials provided as a reference design, even if we
 * are advised of the possibility thereof, nor for any claim by a third party.
 ******************************************************************************/

#include "Pan9320.h"
#include "hw_platform.h"
#include "core_gpio.h"
#include "core_uart_apb.h"

// -- Definitions ------------------------------------------------------------
#define Pan9320_GPIO_CMD_ADDR				0x00000000
#define Pan9320_UART_CMD_ADDR				0x00000100
#define Pan9320_UART_DATA_ADDR			0x00000200

#define FACT_RST				GPIO_0
#define FACT_RST_ON			1
#define FACT_RST_OFF		0

#define RESETn					GPIO_1
#define WIFI_RST_ON		 	0
#define WIFI_RST_OFF		1

#define WAKE_UP					GPIO_2
#define WAKE_ON					1
#define WAKE_OFF				0

#define BT_GRANTn				GPIO_3
#define BT_FREQ					GPIO_4
#define BT_REQ					GPIO_5
#define BT_STATE				GPIO_6

static gpio_instance_t g_gpio_cmd;
static UART_instance_t g_uart_cmd;
static UART_instance_t g_uart_data;


// System commands

const char *SYS_RESTART = "Set system restart\r\n";
const char *SYS_POWER_UP = "Set system psm 0\r\n";
const char *SYS_POWER_SAVE = "Set system psm 1\r\n";
const char *SYS_POWER_DOWN = "Set system psm 2\r\n";

// Netcat config commands (client)
const char *NETCAT_MODE = "set netcat mode server\r\n";
const char *NETCAT_TCP_PORT = "set netcat tcp_port 2018\r\n";
const char *NETCAT_AUTH = "set netcat auth off\r\n";
const char *NETCAT_TELOPT = "set netcat telopt off\r\n";
const char *NETCAT_STATE = "set netcat state on\r\n";
const char *NETCAT_UART = "set binuart cfg 115200 8 0 1 1\r\n";

// --- Private functions -------------------------------------------------------

// --- Public Functions --------------------------------------------------------

void PAN_Init(addr_t interface_addr) {

	GPIO_init(&g_gpio_cmd,
						interface_addr | Pan9320_GPIO_CMD_ADDR,
						GPIO_APB_32_BITS_BUS);

  UART_init(&g_uart_cmd,									// Wifi Command
  					interface_addr | Pan9320_UART_CMD_ADDR,
						BAUD_VALUE_115200,
            (DATA_8_BITS | NO_PARITY));

  UART_init(&g_uart_data,									// Wifi Data
  					interface_addr | Pan9320_UART_DATA_ADDR,
						BAUD_VALUE_115200,
            (DATA_8_BITS | NO_PARITY));

}

void PAN_Disable() {
	GPIO_set_output(&g_gpio_cmd, RESETn, WIFI_RST_ON);
}

void PAN_Enable() {
	GPIO_set_output(&g_gpio_cmd, RESETn, WIFI_RST_OFF);
	for(volatile uint32_t delay = 0; delay < 0x4000000; delay++); // Delay
}

void PAN_Restart() {
	UART_polled_tx_string(&g_uart_cmd, (const uint8_t*) SYS_RESTART);
	for(volatile uint32_t delay = 0; delay < 0x4000000; delay++); // Delay
}

void PAN_Wakeup() {
	GPIO_set_output(&g_gpio_cmd, WAKE_UP, WAKE_ON);
	for(volatile uint16_t delay = 0; delay < 0xF00000; delay++); // Delay
	GPIO_set_output(&g_gpio_cmd, WAKE_UP, WAKE_OFF);
}

void PAN_Config_NetCat() {
  UART_polled_tx_string(&g_uart_cmd, (const uint8_t*) NETCAT_MODE);
  for(volatile uint16_t delay = 0; delay < 0xFFFF; delay++); // Delay
  UART_polled_tx_string(&g_uart_cmd, (const uint8_t*) NETCAT_TCP_PORT);
  for(volatile uint16_t delay = 0; delay < 0xFFFF; delay++); // Delay
  UART_polled_tx_string(&g_uart_cmd, (const uint8_t*) NETCAT_AUTH);
  for(volatile uint16_t delay = 0; delay < 0xFFFF; delay++); // Delay
  UART_polled_tx_string(&g_uart_cmd, (const uint8_t*) NETCAT_TELOPT);
  for(volatile uint16_t delay = 0; delay < 0xFFFF; delay++); // Delay
  UART_polled_tx_string(&g_uart_cmd, (const uint8_t*) NETCAT_UART);
  for(volatile uint16_t delay = 0; delay < 0xFFFF; delay++); // Delay
  UART_polled_tx_string(&g_uart_cmd, (const uint8_t*) NETCAT_STATE);
  for(volatile uint16_t delay = 0; delay < 0xFFFF; delay++); // Delay
}

size_t PAN_ReceiveData(uint8_t *rx_data) {
	if (UART_get_rx_status(&g_uart_data) == UART_APB_NO_ERROR) {
		return(UART_get_rx(&g_uart_data, rx_data, sizeof(*rx_data)));
	}
}

void PAN_SendData(uint8_t *tx_data, size_t tx_size) {
	UART_send(&g_uart_data, tx_data, tx_size);
}
